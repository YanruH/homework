#!/bin/bash
if [ -d "$1" ]; then for var in $(ls "$1"); do echo  | sed 's/[A-Z]*/&&&/'; done; else echo "Not a directory" >printcap3_error.log;
fi
